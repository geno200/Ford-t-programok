﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szimbolumtablas
{
    class Rules
    {
        public string Oszlop1 { get; set; }
        public string Oszlop2 { get; set; }
        public string Oszlop3 { get; set; }
        public string Oszlop4 { get; set; }
        public string Oszlop5 { get; set; }
        public string Oszlop6 { get; set; }
        public string Oszlop7 { get; set; }

        public Rules()
        { 

        }


    }
}
