﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Data;
using System.Windows.Controls;
using System.ComponentModel;
using System.Data.Common;
using System.Text.RegularExpressions;



namespace szimbolumtablas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static DataTable dt;
        private static Stack<string> Term_NTerm;
        private static string Allapot;
        public static string input;
        public static List<string> Atmenetek { get; private set; }
        

        public static string Cella(string oszlop, string sor)
        {
            int oszlopszam = -1;
            int sorszam = -1;


            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if ((string)dt.Rows[0][i]==oszlop)
                {
                    oszlopszam = i;
                    break;
                }
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if ((string)dt.Rows[i][0] == sor)
                {
                    sorszam = i;
                    break;
                }
            }


            if (oszlopszam == -1 || sorszam == -1)
                return "";

           return (string)dt.Rows[sorszam][oszlopszam];
        }

       

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            #region Tábla_betöltés
            Stack<string> Term_es_nem_term = new Stack<string>();
            Term_es_nem_term.Push("E");
            Term_es_nem_term.Push("E'");
            Term_es_nem_term.Push("T");
            Term_es_nem_term.Push("T'");
            Term_es_nem_term.Push("F");
            Term_es_nem_term.Push("+");
            Term_es_nem_term.Push("*");
            Term_es_nem_term.Push("(");
            Term_es_nem_term.Push(")");
            Term_es_nem_term.Push("i");
            Term_es_nem_term.Push("P");
            Term_es_nem_term.Push("E");



            Rules Szabaly = new Rules();
            string[] Szabalytomb;


            dt = new DataTable();
            dt.Columns.Add("Oszlop1", typeof(string));
            dt.Columns.Add("Oszlop2", typeof(string));
            dt.Columns.Add("Oszlop3", typeof(string));
            dt.Columns.Add("Oszlop4", typeof(string));
            dt.Columns.Add("Oszlop5", typeof(string));
            dt.Columns.Add("Oszlop6", typeof(string));
            dt.Columns.Add("Oszlop7", typeof(string));

            using (StreamReader sr = new StreamReader("Rules.csv"))
            {

                while (!sr.EndOfStream)
                {
                    Szabalytomb = sr.ReadLine().Split(';');
                    Szabaly.Oszlop1 = Szabalytomb[0];
                    Szabaly.Oszlop2 = Szabalytomb[1];
                    Szabaly.Oszlop3 = Szabalytomb[2];
                    Szabaly.Oszlop4 = Szabalytomb[3];
                    Szabaly.Oszlop5 = Szabalytomb[4];
                    Szabaly.Oszlop6 = Szabalytomb[5];
                    Szabaly.Oszlop7 = Szabalytomb[6];

                    dt.Rows.Add(Szabalytomb);

                }
                DataView dv = new DataView(dt);
                Szabalyok.ItemsSource = dv;

            }
            #endregion

            Term_NTerm = new Stack<string>();
            Term_NTerm.Push("#");
            Term_NTerm.Push((string)dt.Rows[1][0]);
            Atmenetek = new List<string>();
           
        }

        private  void Ered_ok_Click(object sender, RoutedEventArgs e)
        {
            string expressionstring = Ered_text.Text;

            expressionstring = Regex.Replace(expressionstring, @"[0-9]+", "i");
            if (expressionstring[expressionstring.Length-1] != '#')
            {
                expressionstring += "#";
            }
            Konv_text.Content = expressionstring;

            input = expressionstring;
        }

        private static void Levezetes ()
        {
            
            string expressionstrin_megold = input;

            Atmenetek.Add($"{expressionstrin_megold},{Term_NTerm.Peek()}#,");


            while (Allapot != "Deny" && Allapot != "Error" && expressionstrin_megold.Length != 0)
            {
                string veremelem = Term_NTerm.Pop();
                string be = Convert.ToString(expressionstrin_megold[0]);

                string szabaly = Cella(be, veremelem);

                string[] push = szabaly.Split(',');

                switch (szabaly)
                {
                    case "accept":
                        Allapot = "Accept";
                        Atmenetek.Add("accept");
                        return;

                    case "pop":
                        expressionstrin_megold = expressionstrin_megold.Remove(0, 1);
                        break;

                    case "":
                        Allapot = "error";
                        Atmenetek.Add("error");
                        return;

                    default:
                        for (int i = push[0].Length - 1; i >= 0; i--)
                        {
                            Term_NTerm.Push(Convert.ToString(push[0][i]));
                        }
                        break;
                }


                string[] Megold = Atmenetek.Last().Split(',');

                Megold[0] = expressionstrin_megold;

                Megold[1] = Megold[1].Remove(0, 1);

                if (push[0] != "pop")
                {
                    Megold[1] = Megold[1].Insert(0, push[0]);
                    Megold[2] = Megold[2] + push[1];
                }

                string ki = Megold[0] + ',' + Megold[1] + ',' + Megold[2];

                Atmenetek.Add(ki);
            }
        

    }

        private void Solution_StepByStep_Click(object sender, RoutedEventArgs e)
        {
            Levezetes();

        }
    }
}
