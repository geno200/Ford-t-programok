﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace filemanager
{
    class SHandler
    {
       
            private string path1; // field

            public string Path1  // property
            {
                get { return path1; }   // get method
                set { path1 = value; }  // set method
            }

            private string path2; // field

            public string Path2  // property
            {
                get { return path2; }   // get method
                set { path2 = value; }  // set method
            }

            private string content; // field

            public string Contetnt  // property
            {
                get { return content; }   // get method
                set { content = value; }  // set method
            }

        public SHandler(string path1, string path2)
        {
            this.path1 = path1;
            this.path2 = path2;
        }

        public void openFileToRead()
        {
            StreamReader sr = new StreamReader(File.OpenRead(this.path1));
            this.content = sr.ReadToEnd();
            sr.Close();
        }

        public void openFileToWrite()
        {
            StreamWriter sw = new StreamWriter(File.Open(this.path2, FileMode.Create));
            // sw.WriteLine("some text");
            sw.Flush();
            sw.Close();
        }

        public void ReplaceContent(string sth)
        {
          
        }

    }
}
