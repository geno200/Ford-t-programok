﻿using System;
using System.Collections.Generic;
using System.IO;

namespace filemanager
{

    class Program
    {
        
        static void Main(string[] args)
        {
            SHandler S = new SHandler("path1.txt", "path2.txt");
            S.openFileToRead();
            Console.WriteLine(S.Contetnt);
            S.Contetnt = "Modified text";
            Console.WriteLine(S.Contetnt);
            S.openFileToWrite();
            Console.WriteLine("done");
            Console.ReadKey();


        }
    }
}
