﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace rekurziv
{

    class recursivePRG
    {
        int i = 0;
        string input;

        void S() {
            E();
            elfogad('#');
        }

        public recursivePRG(string input)
        {
            this.input = $"{simple(input)}#";
            S();
            Console.WriteLine("Elemzés lefutott.");
        }


        private string simple(string input)
        {
            Console.WriteLine("Eredeti input {0}", input);
            string v = Regex.Replace(input, "[0-9]+" , "i");
            Console.WriteLine("Egyszerűsített input {0}", v);
            return v;

        }

        void E()
        {
            T();
            Ev();

        }

        void Ev()
        {

            if (input[i] == '+')
            {
                elfogad('+');
                T();
                Ev();
            }
        }

        void T()
        {
            F();
            Tv();
        }

        void Tv()
        {

            if (input[i] == '*')
            {
                elfogad('*');
                F();
                Tv();
            }
        }

        void F()
        {
            if (input[i] == '(')
            {
                elfogad('*');
                E();
                elfogad(')');
            }
            else
            {
                elfogad('i');
                    
            }
        }

        public void elfogad(char c)
        {
            if (input[i] != c)
            {
                Console.WriteLine(" helytelen karakter: {0}",  input[i]);
            }
            
                i++;
           

        }
    }
    class Program
    {
      
        static void Main(string[] args)
        {
            recursivePRG PRG = new recursivePRG("(1+alma)*3");
        }
    }
}
