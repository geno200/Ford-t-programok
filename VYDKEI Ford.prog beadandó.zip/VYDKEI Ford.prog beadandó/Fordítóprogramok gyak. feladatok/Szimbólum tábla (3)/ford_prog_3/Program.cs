﻿//LEXIKÁLIS ELEMZÉS
//IF (A == 20) { B =10}
//IF (VAR(1) == CONST(2)) { VAR (3) = CONST(4)}
//-->10 20 001 40 002 30 50 003 41 004 60 

//A lexikális elemző előállít egy egyszerű homogén
//kódsorozatot a szintaktikai elemzőnek és előállít egy 
//szimbólum táblát is

//-->Szimbólum_tábla[A(adatok),"20"(adatok)]

//"VAR" =
//"IF" =10
//"(" = 20
//")" = 30
//"==" = 40
//"="  = 41
//"{" = 50
//"}" = 60

//content = Regex.Replace(content, @"IF", "10");

using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ford_prog_3
{
    class sourceHanddler
    {
        string path1, path2 = "";
        public string content = "";

        public sourceHanddler(string path1, string path2)
        {
            this.path1 = path1;
            this.path2 = path2;

        }

        public void openFileRead()
        {
            try
            {
                StreamReader SR = new StreamReader
               (File.OpenRead(this.path1));
                content = SR.ReadToEnd();
                SR.Close();
            }
            catch (IOException e)
            {
                Console.Write("Olvasási hiba" + e.Message);

            }
            finally { }


        }

        public void replaceText(string s)
        {
            this.content += s;
        }

        public void replaceFirst(string s)
        {
            content = Regex.Replace(content, "",string.Empty);
            content = Regex.Replace(content, "", string.Empty);
        }
        public void replaceContent(string s)
        {
            this.content += s;
        }

        public void openFileWrite()
        {
            try
            {
                StreamWriter SW = new StreamWriter
                (File.Open(this.path2, FileMode.Create));
                SW.WriteLine(this.content);
                SW.Flush();
                SW.Close();
            }
            catch (IOException e)
            {

                Console.Write("Írási hiba" + e.Message);

            }
            finally { }

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            sourceHanddler SH = new sourceHanddler("f1.txt", "f2.txt");
            SH.openFileRead();
            SH.replaceContent(" új szöveg");
            Console.WriteLine(SH.content);
            SH.openFileWrite();
            Console.ReadKey();


        }
    }
}
