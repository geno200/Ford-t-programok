﻿using System;
using System.IO;
using System.Collections.Generic;

namespace fordprog_2
{
    class sourceHanddler
    {
        string path1, path2 = "";
        public string content = "";

        public sourceHanddler(string path1, string path2)
        {
            this.path1 = path1;
            this.path2 = path2;

        }

        public void openFileRead() {
            try
            {
                StreamReader SR = new StreamReader
               (File.OpenRead(this.path1));
                content = SR.ReadToEnd();
                SR.Close();
            }
            catch (IOException e)
            {
                Console.Write("Olvasási hiba" + e.Message);

            }
            finally { }

           
        }

        public void replaceContent(string s) {
            this.content += s;
        }

        public void openFileWrite()
        {
            try
            {
                StreamWriter SW = new StreamWriter
                (File.Open(this.path2, FileMode.Create));
                SW.WriteLine(this.content);
                SW.Flush();
                SW.Close();
            }
            catch (IOException e)
            {

                Console.Write("Írási hiba" + e.Message);

            }
            finally { }

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            sourceHanddler SH = new sourceHanddler("f1.txt","f2.txt");
            SH.openFileRead();
            SH.replaceContent(" új szöveg");
            Console.WriteLine(SH.content);
            SH.openFileWrite();
            Console.ReadKey();

           
        }
    }
}
