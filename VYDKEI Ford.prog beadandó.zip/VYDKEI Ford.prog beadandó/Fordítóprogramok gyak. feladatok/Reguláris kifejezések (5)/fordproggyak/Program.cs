﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace fordproggyak
{
    //Regex automata
    // Számokat  előjellel és nélkül vizsgál
    //+12, 13 , 2, 000, 001 stb.
    // D = {0,2..., 9}
    // (+|-|e) D+ (pozitív lezárt)
    // "(+,-) [0-9]+"

    class automata
    {
        string input = "+12";
        int i = 0;
        string state;
        Dictionary<string, string> D = new Dictionary<string, string>();

        public automata(string input)
        {
            this.input = input;
            this.state = "q0";
            D.Add("q0+", "q1");
            D.Add("q0-", "q1");
            D.Add("q0d", "q2");
            D.Add("q1d", "q2");
            D.Add("q2d", "q2");

        }

        public char convert(char c)
        {
            if (Char.IsDigit(c))// Számjegy v. nem
            {
                return 'd';
            }
            return c;
        }

        //public string delta(string st, char elem)
        //{
        //    string elemek = st + elem + convert(elem) ;
        //    switch (elemek)
        //    {
        //        case "q0-": return "q1";
        //        case "q0+": return "q1";
        //        case "q0d": return "q2";
        //        case "q1d": return "q2";
        //        case "q2d": return "q2";
        //        default: return "error";

        //    }
        //}

        public string delta(string st, char elem)
        {
            string elemek = st + convert(elem);
            if (D.ContainsKey(elemek))
            {
                return D[elemek];
            }
            return "error";
          
        }

        public void main() {
            while (i<input.Length && state != "error")
            {
                state = delta(state, input[i]);
                i++;


            }

            if (state == "error")
            {
                Console.WriteLine("{0} kifejezés helytelen, a hiba pozíciója {1}, a hibás karakter {2}", input, i, input[i]);
            }

            else
            {
                Console.WriteLine(" Az input kifejezés helyes : {0}", input);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
           automata A = new automata("+12-7");
            A.main();

        }
    }
}
